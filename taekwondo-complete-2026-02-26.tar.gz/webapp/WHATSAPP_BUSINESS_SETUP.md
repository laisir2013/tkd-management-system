# WhatsApp Business API 申請指南

## 當前狀態
- ✅ Twilio WhatsApp Sandbox 已設定完成
- ✅ 測試訊息發送成功
- ⚠️ Sandbox 模式限制:只能發送給已加入 Sandbox 的用戶

## 升級到正式 WhatsApp Business API

### 前置要求
1. **WhatsApp Business 帳號** ✅ (道館已有)
2. **Facebook Business Manager 帳號**
3. **已驗證的 Facebook Business** (需要營業執照)

### 申請流程

#### 第一步:在 Twilio 中申請 WhatsApp Sender
1. 前往 Twilio Console: https://console.twilio.com/
2. 左側選單:Messaging → Senders → WhatsApp senders
3. 點擊 "Request to add a WhatsApp Sender"
4. 選擇 "Use your existing WhatsApp Business number"

#### 第二步:連接 Facebook Business Manager
1. 建立或登入 Facebook Business Manager
2. 將 WhatsApp Business 帳號連接到 Twilio
3. 授權 Twilio 存取 WhatsApp Business 帳號

#### 第三步:提交審核
1. 填寫公司資訊
2. 上傳營業執照(商業登記證)
3. 等待 Facebook 審核(1-3 個工作天)

### 需要準備的資訊
- WhatsApp Business 號碼
- Facebook Business Manager 帳號
- 商業登記證或營業執照
- 公司地址和聯絡資訊

### 費用
- 每則訊息約 HK$0.5-1.0
- 需要預付費用到 Twilio 帳號

### 替代方案
如果申請流程太複雜,可以考慮:
- 使用 SMS 簡訊(立即可用,無需審核)
- 使用其他 WhatsApp Business API 提供商

## 技術實作

系統已經整合 Twilio WhatsApp API,代碼位於:
- `server/_core/whatsapp.ts`: WhatsApp 發送服務
- `server/routers.ts`: 批量發送提醒 API
- `client/src/components/EliteClassBalance.tsx`: 前端發送按鈕

當 WhatsApp Business API 申請完成後,只需要:
1. 在 Twilio Console 中獲取新的 WhatsApp 號碼
2. 更新環境變數 `TWILIO_WHATSAPP_FROM` 為新號碼
3. 系統即可發送訊息給任何 WhatsApp 用戶

## 當前配置

```
TWILIO_ACCOUNT_SID=ACa6bed0ad9887f8525ac4d8b6b39e0690
TWILIO_AUTH_TOKEN=bc374bd3b07baa5f1cc925123c1d41a9
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886 (Sandbox)
```

## 參考資料
- [Twilio WhatsApp API 文檔](https://www.twilio.com/docs/whatsapp/api)
- [WhatsApp Business API 申請指南](https://www.twilio.com/docs/whatsapp/tutorial/connect-number-business-profile)
